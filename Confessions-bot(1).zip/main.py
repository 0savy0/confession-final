import discord
import json
import asyncio
from discord.ext import commands

# Load configuration from a file or initialize it if it doesn't exist
config_file = "config.json"
try:
    with open(config_file, "r") as f:
        config = json.load(f)
except FileNotFoundError:
    config = {}

# Set up the bot and specify the command prefix
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='/', intents=intents, help_command=None)

@bot.event
async def on_ready():
    await bot.change_presence(status=discord.Status.online, activity=discord.Game(name="Confessing Secrets"))
    print(f'Bot {bot.user} is now running.')

    # Start a background task to keep the bot awake
    bot.loop.create_task(keep_alive())

async def keep_alive():
    while True:
        # Send a keep-alive message every 2 minutes
        await bot.change_presence(activity=discord.Game(name="Still here!"))
        await asyncio.sleep(120)  # Wait for two minutes

# Command to set channels
@bot.command(name="set")
@commands.has_permissions(administrator=True)
async def set_channel(ctx, channel_type: str):
    if channel_type.lower() == "confession":
        config["confession_channel_id"] = ctx.channel.id
        await ctx.send(f"Confession channel set to: {ctx.channel.mention}")
    elif channel_type.lower() == "moderator":
        config["moderator_channel_id"] = ctx.channel.id
        await ctx.send(f"Moderator channel set to: {ctx.channel.mention}")
    else:
        await ctx.send("Invalid channel type. Use `/set confession` or `/set moderator`.")

    # Save the updated configuration to file
    with open(config_file, "w") as f:
        json.dump(config, f)

@bot.command(name="confess")
async def confess(ctx, *, message: str):
    # Delete the command message
    await ctx.message.delete()

    # Retrieve the channel IDs from config
    confession_channel_id = config.get("confession_channel_id")
    moderator_channel_id = config.get("moderator_channel_id")

    # Check if channels are set
    if not confession_channel_id or not moderator_channel_id:
        await ctx.send("Confession or moderator channel not set. Use `/set confession` and `/set moderator`.")
        return

    # Get the channels by ID
    confession_channel = bot.get_channel(confession_channel_id)
    moderator_channel = bot.get_channel(moderator_channel_id)

    # Send the anonymous confession to the designated confession channel
    if confession_channel:
        await confession_channel.send(f'Anonymous Confession: {message}')

    # Send a copy of the confession with the sender's info to the moderator channel
    if moderator_channel:
        await moderator_channel.send(
            f"Confession from {ctx.author}:\n{message}"
        )

    # Send a confirmation DM to the user who confessed
    try:
        await ctx.author.send("Your confession has been sent anonymously.")
    except discord.Forbidden:
        await ctx.send("I couldn't send you a DM. Please check your privacy settings.")

@bot.command(name="help")
async def help_command(ctx):
    help_message = (
        "Here are the available commands:\n\n"
        "**/confess [message]**: Sends an anonymous confession to the designated confession channel.\n"
        "   - Example: `/confess I love ice cream!`\n\n"
        "**/set [confession/moderator]**: Sets the current channel as the confession or moderator channel. **Admin only**.\n"
        "   - Example: `/set confession` (run this command in the desired confession channel)\n\n"
        "**/help**: Sends you a private message explaining how to use the bot.\n\n"
        "If you have any questions, feel free to reach out to a server moderator!"
    )
    try:
        await ctx.author.send(help_message)
        await ctx.send("I've sent you a DM with instructions on how to use the bot!")
    except discord.Forbidden:
        await ctx.send("I couldn't send you a DM. Please check your privacy settings.")

# Error handler to inform users if they lack permission
@set_channel.error
async def set_channel_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("You do not have permission to use this command.")

# Replace 'YOUR_BOT_TOKEN' with your actual Discord bot token
bot.run('MTIxNzYwNzUwNjUxNjUwODgwMQ.G10LED.ySfqsDetXf8WhUN3jQDA-rD_ghWUyzW2a3Bj_4')